
import java.util.HashMap;

/**
 *
 * @author rod
 */
interface SQLRequestListener {

	void sqlRequest(SQLRequest request);
}
